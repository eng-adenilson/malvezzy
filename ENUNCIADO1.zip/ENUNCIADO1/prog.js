
function calcularCustoPorMetroQuadrado(area, custoMateriais, custoMaoObra) {
    
    if (area > 0) {
        const custoTotal = custoMateriais + custoMaoObra;
        const custoPorMetro = custoTotal / area;
        return custoPorMetro.toFixed(2); 
    } else {
        return "Entrada inválida!";
    }
}

document.getElementById("calcForm").addEventListener("submit", function(event) {
    event.preventDefault(); 
   
    const area = parseFloat(document.getElementById("area").value);
    const custoMateriais = parseFloat(document.getElementById("custoMateriais").value);
    const custoMaoObra = parseFloat(document.getElementById("custoMaoObra").value);

    
    const custoPorMetro = calcularCustoPorMetroQuadrado(area, custoMateriais, custoMaoObra);

    
    document.getElementById("custoPorMetro").innerText = `R$ ${custoPorMetro}`;
});
